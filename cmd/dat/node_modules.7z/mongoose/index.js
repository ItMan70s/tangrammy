
/**
 * Export lib/mongoose
 *
 */

module.exports = require('./lib/');
